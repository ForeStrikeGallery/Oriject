<header>

		<div class="jumbotron">
		</div>
		<nav class="navbar navbar-default">
		 	<div class="container-fluid">
				<div class="navbar-header">
				  <a class="navbar-brand" href="index.php">Oriject</a>
				</div>
				<ul class="nav navbar-nav">
				  <li class="active"><a href="blog_page.php">Blog</a></li>
				 
				</ul>
		    </div>
		</nav>
	</header>
