<!doctype html>
<html>
<?php 
	include 'includes/head.php';
?>

<body>
	<?php include 'includes/header.php'?>

	<div class="row" style="min-height:500px">
		<div class="col-sm-3">
		</div>
		<div class="col-sm-6">
