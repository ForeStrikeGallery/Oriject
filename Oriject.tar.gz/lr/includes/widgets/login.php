<div class="well" class="container">
	<h2>Log in</h2>

 <form action="login.php" method="post">
	  <div class="form-group">
		<label for="username">Username</label>
		<input type="text" class="form-control" name="username">
	  </div>
	  <div class="form-group">
		<label for="pwd">Password:</label>
		<input type="password" class="form-control" name="password">
	  </div>
	  <div class="checkbox">
		<label><input type="checkbox"> Remember me</label>
	  </div>
	  <button type="submit" class="btn btn-default">Submit</button>
	  <a href="register.php">Register</a>
	  
</form>
</div>
