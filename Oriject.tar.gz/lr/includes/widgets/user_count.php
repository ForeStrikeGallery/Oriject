<div class="well">
	<h4>Registered Users</h4>
	<?php echo user_count();?>
</div>



