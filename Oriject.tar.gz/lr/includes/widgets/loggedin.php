<div class="well">
<h3>
<?php
	echo "Hi! ".$user_data['first_name'] ;
	
?>
</h3>
<form action="logout.php" method="post">
	 <button type="submit" class="btn btn-default">Log Out</button>
</form>
</div>



