<?php 
include 'core/init.php';
include 'includes/overall/overallheader.php'
?>
<h1>Oriject</h1>
<br>
<h3> The blogging website</h3>

<?php include 'includes/overall/overallfooter.php'?>


